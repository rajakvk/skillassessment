/* Author:
SKM
*/


( function(studioTraining, $, undefined) {

	/*
	 * Singletons serve as a namespace provider which isolate implementation code
	 * from the global namespace so as to provide a single point of access for functions,
	 * this is useful for organizing code into logical sections.
	 * It is possible to put parentheses around this structure to instantiate it immediately after it's parsed.
	 * This way it's always present when the script is executed and doesn't have to be instantiated separately.
	 */

	studioTraining.testAssign = ( function() {
		function _testAssign() {
			var _this = this, current, maximum, visible, step, speed, liSize;
						
				_this.yrlyReport=(function (){

					var selectedData = ''; 
					$('td.month, td.task, td.status').empty();
					var table = $('<table border="0" width="100%" cellpadding="0" cellspacing="0" class="generic-table"><tr><th>Month</th><th>Task</th><th>Status</th></tr><tr class="dataRecord"><td class="month"></td><td class="task"></td><td class="status"></td></tr></table>');
					$(table).insertAfter('select.yearlyReport');
					$.getJSON("js/project_record.txt", function(data){
					selectedData = $('select.yearlyReport :selected').index();
					var tdMonth = "";
					var tdTask = "";
					var tdStatus = "";
					$.each(data.ProjectData.record[selectedData].data.month, function(i, month){
					tdMonth = month;
					$('<table><tr>'+tdMonth+'</tr></table').appendTo('td.month');
					});
					$.each(data.ProjectData.record[selectedData].data.task, function(i, task){
					tdTask = task;
					$('<table><tr>'+tdTask+'</tr></table').appendTo('td.task');
					});
					$.each(data.ProjectData.record[selectedData].data.status, function(i, status){
					tdStatus = status;
					$('<table><tr>'+tdStatus+'</tr></table').appendTo('td.status');
					});

					});

					$('select.yearlyReport').change(function(){
					$('td.month, td.task, td.status').empty();
					selectedData = $('select.yearlyReport :selected').index();
					$.getJSON("js/project_record.txt", function(data){
					selectedData = $('select.yearlyReport :selected').index();
					var tdMonth = "";
					var tdTask = "";
					var tdStatus = "";
					$.each(data.ProjectData.record[selectedData].data.month, function(i, month){
					tdMonth = month;
					$('<table><tr>'+tdMonth+'</tr></table').appendTo('td.month');
					});
					$.each(data.ProjectData.record[selectedData].data.task, function(i, task){
					tdTask = task;
					$('<table><tr>'+tdTask+'</tr></table').appendTo('td.task');
					});
					$.each(data.ProjectData.record[selectedData].data.status, function(i, status){
					tdStatus = status;
					$('<table><tr>'+tdStatus+'</tr></table').appendTo('td.status');
					});

					});
					});
				});


				_this.carousel=(function (){
			  //rotation speed and timer
				var speed = 5000;

     
				//grab the width and calculate left value
				var item_width = $('.slides p').outerWidth();
				
				var left_value = item_width * (0);

         
				//move the last item before first item, just in case user click prev button
				$('.slides p:first').before($('.slides p:last'));
     
				//set the default item to the correct position
				$('.slides').css({'left' : left_value});
 
				//if user clicked on prev button
				$('.prevButton').click(function() {
 
				//get the right position           
				var left_indent = parseInt($('.slides').css('left')) + item_width;
 
        //slide the item           
        $('.slides').animate({'left' : left_indent}, 200,function(){   
 
            //move the last item and put it as first item              
            $('.slides p:first').before($('.slides p:last'));          
 
            //set the default item to correct position
            $('.slides').css({'left' : left_value});
         
        });
 
        //cancel the link behavior           
        return false;
             
    });
 
  
    //if user clicked on next button
    $('.nextButton').click(function() {
         
        //get the right position
        var left_indent = parseInt($('.slides').css('left')) - item_width;
		
         
        //slide the item
        $('.slides').animate({'left' : left_indent}, 100, function () {
             
            //move the first item and put it as last item
            $('.slides p:last').after($('.slides p:first'));                 
             
            //set the default item to correct position
            $('.slides').css({'left' : left_value});
         
        });
                  
        //cancel the link behavior
        return false;
         
    });       
 
         
});

_this.overlay=(function (){


    $('#activator').click(function(){
        $('#overlay').fadeIn('fast',function(){
            $('#box').animate({'top':'300px'},500);
        });
    });
    $('#boxclose').click(function(){
        $('#box').animate({'top':'-500px'},500,function(){
            $('#overlay').fadeOut('fast');
        });
 
});
});

//a simple function to click next link
//a timer will call this function, and the rotation will begin :) 

			_this.init = function() {
				_this.yrlyReport();
				_this.overlay();
				_this.carousel();
				return this;
				/*this refere to MODULE.formValidate*/
			};
			return _this.init();
			/*this refere to MODULE.formValidate.init()*/
		}

		return new _testAssign();
		/*creating a new object of formValidate rather then a funtion*/
	}());
	/**
	 * Check to evaluate whether 'MODULE' exists in the global namespace - if not, assign window.MODULE an object literal
	 */
}(window.studioTraining = window.studioTraining || {}, jQuery));





